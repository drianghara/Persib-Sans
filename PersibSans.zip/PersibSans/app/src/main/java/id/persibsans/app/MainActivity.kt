package id.persibsans.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream

class MainActivity : Activity() {

    private val base = "https://www.persibsans.id"
    private val navy = Color.parseColor("#0b132b")
    private val blue = Color.parseColor("#1e63d6")

    private val tabs = listOf(
        "Home" to "$base/",
        "Persib" to "$base/search/label/Persib",
        "Liga 1" to "$base/search/label/Liga%201",
        "Transfer" to "$base/search/label/Transfer",
        "Jadwal" to "$base/search/label/Jadwal",
        "Hasil" to "$base/search/label/Hasil"
    )

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private val tabViews = mutableListOf<TextView>()

    // Halaman / domain live streaming diblokir sepenuhnya.
    private val blockedHostParts = listOf("afmtv", "adritv")
    private val blockedPathParts = listOf("live-streaming", "livestreaming", "nobar", "/p/p1")

    private fun isBlocked(uri: Uri): Boolean {
        val host = (uri.host ?: "").lowercase()
        val path = (uri.encodedPath ?: "").lowercase()
        if (blockedHostParts.any { host.contains(it) }) return true
        if (host.endsWith("persibsans.id") && blockedPathParts.any { path.contains(it) }) return true
        return false
    }

    // Menyembunyikan blok "LIVE STREAMING" di halaman beranda & menghapus iframe.
    private val cleanJs = """
        (function() {
            function clean() {
                try {
                    document.querySelectorAll('iframe').forEach(function(f) { f.remove(); });
                    document.querySelectorAll('a[href*="live-streaming"], a[href*="afmtv"]').forEach(function(a) {
                        a.style.display = 'none';
                    });
                    var best = null, bestLen = 1e9;
                    document.querySelectorAll('section,div,aside,article').forEach(function(el) {
                        var t = (el.textContent || '').toUpperCase();
                        if (t.indexOf('LIVE STREAMING') > -1 && t.indexOf('PILIH SERVER') > -1) {
                            if (t.length < bestLen) { best = el; bestLen = t.length; }
                        }
                    });
                    if (best && bestLen < 3000) { best.style.display = 'none'; }
                } catch (e) {}
            }
            clean();
            new MutationObserver(clean).observe(document.documentElement, {childList: true, subtree: true});
        })();
    """.trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 6)
        }

        web = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (isBlocked(uri)) {
                    Toast.makeText(
                        this@MainActivity,
                        "Live streaming tidak tersedia di aplikasi ini",
                        Toast.LENGTH_SHORT
                    ).show()
                    return true
                }
                val host = (uri.host ?: "").lowercase()
                if (host.endsWith("persibsans.id")) return false
                // Link luar dibuka di browser
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (_: Exception) {
                }
                return true
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (isBlocked(request.url)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                view.evaluateJavascript(cleanJs, null)
            }

            override fun onPageFinished(view: WebView, url: String) {
                view.evaluateJavascript(cleanJs, null)
                highlightTab(url)
            }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(navy)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 140)
        }
        tabs.forEachIndexed { i, (label, url) ->
            val tv = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.LTGRAY)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener { web.loadUrl(url); select(i) }
            }
            tabViews.add(tv)
            bar.addView(tv)
        }

        root.addView(progress)
        root.addView(web)
        root.addView(bar)
        setContentView(root)

        if (savedInstanceState == null) {
            web.loadUrl(tabs[0].second)
            select(0)
        } else {
            web.restoreState(savedInstanceState)
        }
    }

    private fun select(index: Int) {
        tabViews.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == index) Color.WHITE else Color.LTGRAY)
            tv.setBackgroundColor(if (i == index) blue else Color.TRANSPARENT)
        }
    }

    private fun highlightTab(url: String) {
        val idx = when {
            url.contains("label/Persib") -> 1
            url.contains("label/Liga") -> 2
            url.contains("label/Transfer") -> 3
            url.contains("label/Jadwal") -> 4
            url.contains("label/Hasil") -> 5
            url.trimEnd('/') == base -> 0
            else -> -1
        }
        if (idx >= 0) select(idx)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
